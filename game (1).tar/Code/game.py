print('███████████████欢迎来到地下城，卑微的凡人███████████████')
Y =input('''请选择你的职业：
                   A : 战士
                   B : 法师
                   ''')
if Y =='A':
    print('战士')
elif Y == 'B':
    print('法师')
else:
    print('时代变了吗')
level =int(input('请输入你的等级：'))
if level<=49:
    print('卑微的蝼蚁啊，怎敢挑战我')
elif level>=100:
    print('哼，让我看看你的气量吧')
else:
    print('哼，凡人')
print('————————开始冒险————————')

